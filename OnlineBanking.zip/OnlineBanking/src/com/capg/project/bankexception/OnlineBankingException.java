package com.capg.project.bankexception;

/*
 * Author by Kumar Satyam
 * Last modified on 07 Sep 2018 
 */

public class OnlineBankingException extends Exception{

	private static final long serialVersionUID = 1L;
	public OnlineBankingException(String message)
	{
		super(message);
	}

}
