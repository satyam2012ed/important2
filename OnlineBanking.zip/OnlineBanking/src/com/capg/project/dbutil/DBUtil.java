package com.capg.project.dbutil;

/*
 * Author by Kumar Satyam
 * Last modified on 07 Sep 2018 
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {

	public static Connection getConn() {
		
		Connection conn=null ;
		//get connection
		try {
			
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg229","training229");
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return conn;
	}
}
