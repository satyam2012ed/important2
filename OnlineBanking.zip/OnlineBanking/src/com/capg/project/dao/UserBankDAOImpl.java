package com.capg.project.dao;

/*
 * Author by Kumar Satyam
 * Last modified on 10 Sep 2018 
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


import java.util.Date;

import org.apache.log4j.Logger;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.BankAdmin;
import com.capg.project.bean.BankUser;
import com.capg.project.dbutil.DBUtil;
import com.capg.project.ui.MainBank;

public class UserBankDAOImpl implements IUserBankDAO {
	Logger logger = Logger.getLogger("MyLogger");
	BankUser bankUser = new BankUser();
	MainBank mainBank = new MainBank();
	BankAdmin bankAdmin = new BankAdmin();
	
	int n = 0;
	int c = 0;
	ResultSet resultSet = null;

	
	/* This method deals with the login of user or admin based on information provided.
	 * It retrieves user id and password from user table and checks whether person
	 * who is logging in is either user or admin */
	@Override
	public int login(String userid, String password) throws OnlineBankingException {
		
		Connection connection = DBUtil.getConn();
		String type = "";
		
		try {
			PreparedStatement pstmt = connection.prepareStatement(IQueryBankMapper.QUERY_LOGIN);
			pstmt.setString(1, userid);
			pstmt.setString(2, password);
			resultSet = pstmt.executeQuery();
			
			while (resultSet.next()) {
				type = resultSet.getString(8);
			}
			if ("admin".equalsIgnoreCase(type)) {
				n = 1;
			} else if ("user".equalsIgnoreCase(type)) {
				n = 0;
			} else {
				n = -1;
			}

		} catch (SQLException e1) {
			logger.error("Login error occurred");
			throw new OnlineBankingException("problem : " + e1.getMessage());

		}
		return n;
	}
	
	
	/*
	 * This method is used to display the current communication address. 
	 * It retrieves account id from user table and display the address 
	 * for that particular account id.
	 */
	@Override
	public int changeInCommunicationAddress(String userid)
			throws OnlineBankingException {
		Connection connection = DBUtil.getConn();
		try {
			String selectQuery = IQueryBankMapper.QUERY_RETRIEVE_ACCOUNT_ID;
			PreparedStatement pstmt = connection.prepareStatement(selectQuery);
			pstmt.setString(1, userid);
			resultSet = pstmt.executeQuery();
			resultSet.next();
			int accountId = resultSet.getInt(1);

			PreparedStatement pstmt1 = connection.prepareStatement(IQueryBankMapper.QUERY_DISPLAY_COMMUNICATION_ADDRESS);
			pstmt1.setInt(1, accountId);
			resultSet = pstmt1.executeQuery();
			n=0;
			while(resultSet.next())
			{
				n=1;
				logger.info("Address and mobile number is displayed");
				System.out.println("Address is :" + resultSet.getString(1));
				System.out.println("Mobile Number is :" + resultSet.getString(2));
				System.out.println("");
				bankUser.setCusaddr(resultSet.getString(1));
				bankUser.setMobileNumber(resultSet.getString(2));
			}
			
			
			
		} catch (SQLException e1) {
			logger.error("Error occurred in displaying communication address");
			throw new OnlineBankingException("problem : " + e1.getMessage());
		}
		return n;

	}
	
	
	/*
	 * This method is used to change the current communication address. 
	 * It retrieves account id from user table and update the new user name,
	 * address and mobile number based on that account id.
	 */
	public int changeInCommunicationAddress(String userid, String address,
			String number) throws OnlineBankingException {
		Connection connection = DBUtil.getConn();

		try {
			PreparedStatement pstmt = connection.prepareStatement(IQueryBankMapper.QUERY_CHANGE_ADDRESS);
			pstmt.setString(1, address);
			pstmt.setString(2, number);
			pstmt.setString(3, userid);
			n = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			logger.error("Error occurred in changing communication address");
			throw new OnlineBankingException("Problem : " + e.getMessage());
		}
		return n;
	}

	
	/*
	 * This method is used to do the request for new cheaque book. It retrieves 
	 * account id from user table and based on that it inserts details into service tracker
	 * table and display the auto generated service id (using sequence) to the user. 
	 */
	@Override
	public int chequeBookRequest(String userid, String description)
			throws OnlineBankingException {
		Connection connection = DBUtil.getConn();
		int sid = 0;

		try {
			String selectQuery = IQueryBankMapper.QUERY_RETRIEVE_ACCOUNT_ID;
			PreparedStatement pstmt = connection.prepareStatement(selectQuery);
			pstmt.setString(1, userid);
			resultSet = pstmt.executeQuery();
			resultSet.next();
			int accountId = resultSet.getInt(1);
			bankUser.setCusid(accountId);

			String insertQuery = IQueryBankMapper.QUERY_INSERT_SERVICE;
			PreparedStatement ptst = connection.prepareStatement(insertQuery);
			ptst.setString(1, description);
			ptst.setInt(2, accountId);
			n = ptst.executeUpdate();

			PreparedStatement ptst1 = connection.prepareStatement(IQueryBankMapper.QUERY_RETRIEVE_SERVICE_ID);
			resultSet = ptst1.executeQuery();
			resultSet.next();
			sid = resultSet.getInt(1);
			
		} catch (SQLException e) {
			logger.error("Exception occurred while requestion for cheaque book");
			throw new OnlineBankingException("problem : " + e.getMessage());
		}

		return sid;

	}

	
	/*
	 * This method is used to track the status of the service requested by the user.
	 * It retrieves the account id from user table and takes the service id from user
	 * and display the service status from service tracker table for particular id. 
	 */
	@Override
	public String trackServiceRequest(BankUser bankUser) throws OnlineBankingException {
		Connection connection = DBUtil.getConn();
		String status = "";
		int accountId = 0;
		try {
			PreparedStatement pstm = connection.prepareStatement(IQueryBankMapper.QUERY_RETRIEVE_ACCOUNT_ID);
			pstm.setString(1, bankUser.getUserName());
			resultSet = pstm.executeQuery();
			while (resultSet.next()) {
				accountId = resultSet.getInt(1);
			}

			PreparedStatement pstmt = connection.prepareStatement(IQueryBankMapper.QUERY_RETRIEVE_SERVICE_STATUS);
			pstmt.setInt(1, bankUser.getServiceId());
			pstmt.setInt(2, accountId);
			resultSet = pstmt.executeQuery();
			
			while (resultSet.next()) {
				status = resultSet.getString(1);
				}
			
			if(status=="") {
				status=null;
			}
			
			
		} catch (SQLException e) {
			logger.error("Problem occurred while tracking service request");
			throw new OnlineBankingException("Problem : " + e.getMessage());
		}
		return status;

	}

	
	/*
	 * This method is used to transfer the amount to another user.
	 * It retrieves the transaction password from the user table and takes the account id. Then it checks
	 * from account master table whether balance is greater than the fund transfer amount. It checks payee table
	 * and sees whether customer's account is in same bank or not. It yes, then it can transfer more than 10 lakh.
	 * It takes input from user and inserts into fund transfer table, transaction table and after the transaction,
	 * it updates the amount into account master table also.
	 */
	@Override
	public int fundTransfer(String userid, BankUser bankUser1, BankAdmin bankAdmin)
			throws OnlineBankingException {
		Connection connection = DBUtil.getConn();

		try{
			String transactionPassword = "";
			int account_id=0;
			PreparedStatement pstm = connection.prepareStatement(IQueryBankMapper.QUERY_DISPLAY_USER_DETAILS);
			pstm.setString(1,userid);
			resultSet=pstm.executeQuery();
			while(resultSet.next())
			{
				transactionPassword = resultSet.getString(6);
				account_id=resultSet.getInt(1);
			}
			long balance = 0;
			if(transactionPassword.equals(bankAdmin.getTransactionpassword()))
			{
				PreparedStatement pstm1 = connection.prepareStatement(IQueryBankMapper.QUERY_DISPLAY_ACCOUNTMASTER_DETAILS);
				pstm1.setInt(1,account_id);
				ResultSet resultSet1=pstm1.executeQuery();
				while(resultSet1.next())
				{
					 balance = resultSet1.getInt(3);
				}
				if(balance>bankUser1.getTransferAmount())
				{
					int i =0;
					PreparedStatement pstmt = connection.prepareStatement(IQueryBankMapper.QUERY_DISPLAY_PAYEE_TABLE);
					pstmt.setInt(1,account_id);
					resultSet=pstmt.executeQuery();
					while(resultSet.next())
					{
						
						if(resultSet.getInt(2) == bankUser1.getPayeeAccount())
						{
							PreparedStatement pstm2 = connection.prepareStatement(IQueryBankMapper.QUERY_RETRIEVE_CUSTOMER_NAME);
							pstm2.setInt(1,account_id);
							ResultSet resultSet;
							resultSet=pstm2.executeQuery();
							resultSet.next();
							String cusname = resultSet.getString(1);
							
							PreparedStatement pstm3 = connection.prepareStatement(IQueryBankMapper.QUERY_RETRIEVE_CUSTOMER_NAME);
							pstm3.setInt(1,bankUser1.getPayeeAccount());
							ResultSet resultSet11;
							resultSet11=pstm3.executeQuery();
							String cusname1="";
							while(resultSet11.next())
							{
								 cusname1 = resultSet11.getString(1);
							}
							
							if(cusname.equalsIgnoreCase(cusname1))
							{
								PreparedStatement pstmt1 = connection.prepareStatement(IQueryBankMapper.QUERY_INSERT_FUNDTRANSFER);
								pstmt1.setInt(1,account_id);
								pstmt1.setInt(2, bankUser1.getPayeeAccount());
								pstmt1.setLong(3,bankUser1.getTransferAmount());
								
								n=pstmt1.executeUpdate();
								
								PreparedStatement pstmt2 = connection.prepareStatement(IQueryBankMapper.QUERY_INSERT_TRANSACTION);
								pstmt2.setLong(1,bankUser1.getTransferAmount());
								pstmt2.setInt(2,account_id);
								
								n=n+pstmt2.executeUpdate();
								
								PreparedStatement pstmt3 = connection.prepareStatement(IQueryBankMapper.QUERY_UPDATE_ACCOUNTMASTER);
								pstmt3.setLong(1,bankUser1.getTransferAmount());
								pstmt3.setInt(2,account_id);
								
								n=n+pstmt3.executeUpdate();
							}
							else{
								if(bankUser1.getTransferAmount()<= 1000000)
								{
									PreparedStatement pstmt1 = connection.prepareStatement(IQueryBankMapper.QUERY_INSERT_FUNDTRANSFER);
									pstmt1.setInt(1,account_id);
									pstmt1.setInt(2, bankUser1.getPayeeAccount());
									pstmt1.setLong(3,bankUser1.getTransferAmount());
									
									n=pstmt1.executeUpdate();
									
									PreparedStatement pstmt2 = connection.prepareStatement(IQueryBankMapper.QUERY_INSERT_TRANSACTION);
									pstmt2.setLong(1,bankUser1.getTransferAmount());
									pstmt2.setInt(2,account_id);
									
									n=n+pstmt2.executeUpdate();
									
									PreparedStatement pstmt3 = connection.prepareStatement(IQueryBankMapper.QUERY_UPDATE_ACCOUNTMASTER);
									pstmt3.setLong(1,bankUser1.getTransferAmount());
									pstmt3.setInt(2,account_id);
									
									n=n+pstmt3.executeUpdate();
								}
								else
								{
									logger.error("Please enter amount less than 10 Lakh");
									System.out.println("Please enter amount less than 10 Lakh");
								}
							}
							
							break;
						}
					}
					
				}
				else{
					logger.error("Entered amount is greater the available balance");
					System.out.println("Entered amount is greater the available balance");
				}
			}
			
			
		}
		catch(SQLException e){
			logger.error("Problem occurred in fund transfer");
			throw new OnlineBankingException("problem : "+e.getMessage());
		}
		
		return n;

	}

	
	/*
	 * This method is used to change the current password of the user. It takes the current password
	 * and updates it into the user table using user id.
	 */
	@Override
	public int changePassword(String newPassword, String userId)
			throws OnlineBankingException {
		Connection connection = DBUtil.getConn();
		bankUser = new BankUser();
		try {
						
			PreparedStatement pstmt = connection
					.prepareStatement(IQueryBankMapper.QUERY_UPDATE_USERTABLE);
			pstmt.setString(1, newPassword);
			pstmt.setString(2, userId);

			n = pstmt.executeUpdate();

		} catch (SQLException e) {
			logger.error("Problem occurred in changing password");
			throw new OnlineBankingException("problem : " + e.getMessage());
		}
		return n;
	}

	
	/*
	 * This method is used to display transaction details. It retrieves details from
	 * user table based on account id and date of transaction provided by user.
	 */
	@Override
	public ArrayList<BankUser> viewMiniStatement(String userid, int tranDuration)
			throws OnlineBankingException {
		
		Connection connection = DBUtil.getConn();
		ArrayList<BankUser> arrayList = new ArrayList<BankUser>();
		
		
		try{
			int account_id=0;
			PreparedStatement pst = connection.prepareStatement(IQueryBankMapper.QUERY_DISPLAY_USER_DETAILS);
			pst.setString(1,userid);
			resultSet=pst.executeQuery();
			while(resultSet.next())
			{
				account_id=resultSet.getInt(1);
			}
			PreparedStatement pstmt = connection.prepareStatement(IQueryBankMapper.QUERY_DISPLAY_TRANSACTION_DETAILS);
			pstmt.setInt(1,account_id);
			pstmt.setInt(2,tranDuration);
			resultSet=pstmt.executeQuery();
			
			while(resultSet.next()){
				BankUser bankUser = new BankUser();
				int transaction_ID = resultSet.getInt(1);
				String tran_Description = resultSet.getString(2);
				Date dateofTransaction = resultSet.getDate(3);
				String transactionType = resultSet.getString(4);
				int transferAmount = resultSet.getInt(5);
				int account_No = resultSet.getInt(6);
				
				bankUser.setTransaction_ID(transaction_ID);
				bankUser.setTran_Description(tran_Description);
				bankUser.setDateofTransaction(dateofTransaction);
				bankUser.setTransactionType(transactionType);
				bankUser.setCusid(account_No);
				bankUser.setTransferAmount(transferAmount);
				arrayList.add(bankUser);
			}
			
		}
		catch(SQLException e){
			logger.info("Error in viewing mini statement");
			throw new OnlineBankingException("problem : "+e.getMessage());
		}
		return arrayList;

	}

}
