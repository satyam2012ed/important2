package com.capg.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import org.apache.log4j.Logger;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.BankAdmin;
import com.capg.project.bean.BankUser;
import com.capg.project.dbutil.DBUtil;

public class AdminBankDAOImpl implements IAdminBankDAO {
	
	Logger logger = Logger.getLogger("MyLogger");
	int n=0;
	ResultSet resultSet = null;
	@Override
	public int createNewAccount(BankAdmin bankAdmin) throws OnlineBankingException {
		Connection connection=DBUtil.getConn();
		int aid = 0;
		
		try{
			PreparedStatement pstmt = connection.prepareStatement(IQueryBankMapper.QUERY_INSERT_CUSTOMER);
			pstmt.setString(1, bankAdmin.getCustomerName());
			pstmt.setString(2,bankAdmin.getCustomeremail());
			pstmt.setString(3,bankAdmin.getCustomeraddress());
			pstmt.setString(4, bankAdmin.getMobileNumber());
			
			 n = pstmt.executeUpdate();
			 
			 PreparedStatement pstmt1 = connection.prepareStatement(IQueryBankMapper.QUERY_INSERT_ACCOUNTMASTER);
			 pstmt1.setString(1,bankAdmin.getAccountType());
			 pstmt1.setInt(2,bankAdmin.getOpeningBalance());
			 
			 n= n+ pstmt1.executeUpdate();
			 PreparedStatement pstmt3 = connection.prepareStatement(IQueryBankMapper.QUERY_INSERT_USERTABLE);
			 pstmt3.setString(1,bankAdmin.getSecurityQuestion());
			 pstmt3.setString(2,bankAdmin.getSecurityAnswer());
			 
			 n= n+pstmt3.executeUpdate();
			 
			 PreparedStatement pstmt2 = connection.prepareStatement(IQueryBankMapper.QUERY_RETRIEVE_ACC_SEQ);
			 resultSet = pstmt2.executeQuery();
			 while(resultSet.next())
			 {
				 aid=resultSet.getInt(1);
			 }
		}
		catch(SQLException e){
			logger.error("SQLException occured");
			throw new OnlineBankingException("problem : "+e.getMessage());
		}
		return aid;
	}

	
	@Override
	public ArrayList<BankUser> viewTransaction(int account_id,int tranDuration) throws OnlineBankingException {
		Connection connection=DBUtil.getConn();
		ArrayList<BankUser> arrayList = new ArrayList<BankUser>();
		
		try {
			PreparedStatement pstmt = connection.prepareStatement("select * from Transactions where Account_No=? and sysdate-DateofTransaction<=?");
			pstmt.setInt(1,account_id);
			pstmt.setInt(2,tranDuration);
			resultSet=pstmt.executeQuery();
			
			while(resultSet.next()){
				BankUser bankUser1 = new BankUser();
				
				int transaction_ID = resultSet.getInt(1);
				String tran_Description = resultSet.getString(2);
				Date dateofTransaction = resultSet.getDate(3);
				String transactionType = resultSet.getString(4);
				int transferAmount = resultSet.getInt(5);
				int account_No = resultSet.getInt(6);
				
				bankUser1.setTransaction_ID(transaction_ID);
				bankUser1.setTran_Description(tran_Description);
				bankUser1.setDateofTransaction(dateofTransaction);
				bankUser1.setTransactionType(transactionType);
				bankUser1.setCusid(account_No);
				bankUser1.setTransferAmount(transferAmount);
				arrayList.add(bankUser1);
			}
		}
		catch(SQLException e){
			logger.error("Invalid Query");
			throw new OnlineBankingException("problem : "+e.getMessage());
		}
		return arrayList;
	}

	
}
