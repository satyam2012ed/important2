package com.capg.project.dao;

/*
 * Author by Kumar Satyam
 * Last modified on 07 Sep 2018 
 */

public interface IQueryBankMapper {

	String QUERY_LOGIN = "Select * from User_Table where user_id=? and login_password=?";
	String QUERY_RETRIEVE_ACCOUNT_ID = "select account_id from user_table where user_id=?";
	String QUERY_DISPLAY_COMMUNICATION_ADDRESS = "select Address,MobileNumber from CUSTOMER where Account_ID =?";
	String QUERY_CHANGE_ADDRESS = "Update customer SET Address=? , MobileNumber=? where Account_ID=(Select Account_ID from user_table where User_id=?)";
	String QUERY_INSERT_SERVICE = "insert into SERVICE_TRACKER values(Serv_id.NEXTVAL,?,?,sysdate,'Open')";
	String QUERY_RETRIEVE_SERVICE_ID = "select Serv_id.currval from SERVICE_TRACKER";
	String QUERY_RETRIEVE_SERVICE_STATUS = "Select Service_status from Service_Tracker where service_id=? and Account_ID =?";
	String QUERY_DISPLAY_USER_DETAILS = "select * from User_Table where user_id=?";
	String QUERY_DISPLAY_ACCOUNTMASTER_DETAILS = "select * from Account_Master where Account_ID=?";
	String QUERY_DISPLAY_PAYEE_TABLE = "select * from Payee_Table where Account_ID=?";
	String QUERY_RETRIEVE_CUSTOMER_NAME = "select Customer_Name from customer where Account_ID = ?";
	String QUERY_INSERT_FUNDTRANSFER ="insert into Fund_Transfer values(Fundtrans_id.nextval,?,?,sysdate,?)";
	String QUERY_INSERT_TRANSACTION ="insert into Transactions values(tran_id.nextval,'Deposit',sysdate,'D',?,?)";
	String QUERY_UPDATE_ACCOUNTMASTER = "Update Account_Master SET Account_Balance = Account_Balance-? where Account_ID = ?";
	String QUERY_UPDATE_USERTABLE = "Update User_Table SET Login_Password = ? where user_id  = ?";
	String QUERY_DISPLAY_TRANSACTION_DETAILS = "select * from Transactions where Account_No=? and sysdate-DateofTransaction<=?";
	String QUERY_INSERT_CUSTOMER = "insert into Customer(Account_ID,Customer_Name,Email,Address,MobileNumber) values(acc_seq.nextval,?,?,?,?)";
	String QUERY_INSERT_ACCOUNTMASTER = "insert into Account_Master values(acc_seq.currval,?,?,sysdate)";
	String QUERY_INSERT_USERTABLE = "insert into user_table values(acc_seq.currval,user_seq.nextval,'newbee',?,?,'trannew','N','user')";
	String QUERY_RETRIEVE_ACC_SEQ = "select acc_seq.currval from dual";
	
}
