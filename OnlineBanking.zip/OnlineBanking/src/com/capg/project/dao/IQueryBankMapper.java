package com.capg.project.dao;

public interface IQueryBankMapper {

	String QUERY_INSERT = "";
}
