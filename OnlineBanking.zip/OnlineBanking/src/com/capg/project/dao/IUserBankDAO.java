package com.capg.project.dao;

/*
 * Author by Kumar Satyam
 * Last modified on 10 Sep 2018 
 */

import java.util.ArrayList;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.BankAdmin;
import com.capg.project.bean.BankUser;

public interface IUserBankDAO {
	 public abstract int login(String userid,String password) throws OnlineBankingException;
	 public abstract int changeInCommunicationAddress(String userid) throws OnlineBankingException;
	 public abstract int changeInCommunicationAddress(String userid, String addr, String number) throws OnlineBankingException;
	 public abstract int chequeBookRequest(String userid,String desc) throws OnlineBankingException;
	 public abstract String trackServiceRequest(BankUser bankUser) throws OnlineBankingException;
	 public abstract int fundTransfer(String userid,BankUser bankUser1,BankAdmin au1) throws OnlineBankingException;
	 public abstract int changePassword(String newPassword,String userid) throws OnlineBankingException;
	 public abstract ArrayList<BankUser> viewMiniStatement(String userid,int tranDuration) throws OnlineBankingException;
}
