package com.capg.project.dao;

import java.util.ArrayList;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.BankAdmin;
import com.capg.project.bean.BankUser;



public interface IAdminBankDAO {
	public abstract int createNewAccount(BankAdmin bankAdmin) throws OnlineBankingException;
	 public abstract ArrayList<BankUser> viewTransaction(int account_id,int tranDuration) throws OnlineBankingException;
	

}
