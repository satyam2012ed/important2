package com.capg.project.ui;

import java.util.*;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.BankAdmin;
import com.capg.project.bean.BankUser;
import com.capg.project.service.AdminBankServiceImpl;
import com.capg.project.service.IAdminBankService;
import com.capg.project.service.IUserBankService;
import com.capg.project.service.UserBankServiceImpl;

public class MainBank {

	static int count = 0;

	public static void main(String[] args) throws OnlineBankingException {

		Logger logger = Logger.getLogger("MyLogger");

		BankUser bankUser = new BankUser();
		BankAdmin bankAdmin = new BankAdmin();
		IUserBankService serviceUser = new UserBankServiceImpl();
		IAdminBankService serviceAdmin = new AdminBankServiceImpl();

		int i, flag;
		String newpassword;
		String oldpassword;
		String pass, userid;
		int n = 0;

		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		System.out.println("");
		System.out.println("************Welcome to Online Banking***********");
		System.out.println("");
		do {
			try {
				System.out.println("Login as :");
				System.out.println(" 1.User");
				System.out.println(" 2.Admin");
				i = scanner.nextInt();

				switch (i) {
				case 1:
				case 2:
					do {
						System.out.println("Enter Id:");
						userid = scanner.next();
						bankUser.setUserName(userid);
						System.out.println("Enter Password:");
						pass = scanner.next();
						bankUser.setPassword(pass);

						try {

							// User login is done and can do listed service.
							if (serviceUser.login(userid, pass) == 0) {

								char j = 'N';
								do {
									System.out.println("Login Successful");

									System.out
											.println("************************************************");
									System.out.println("");
									System.out
											.println("1. Change In Communication Address:");
									System.out
											.println("2. Request For Cheaque Book:");
									System.out
											.println("3. Track  Service Request:");
									System.out.println("4. Fund Transfer:");
									System.out.println("5. Change Password:");
									System.out.println("6. Mini Statement:");
									System.out.println("");
									System.out
											.println("************************************************");

									System.out.println("");
									System.out.println("Select your service: ");
									i = scanner.nextInt();
									System.out
											.println("************************************************");
									System.out.println("");

									switch (i) {

									// Displaying and changing the communication
									// address
									case 1:
										String number = "";
										boolean num = false;
										System.out
												.println("Your Communication Address is:");
										serviceUser
												.changeInCommunicationAddress(userid);
										do {
											System.out
													.println("************************************************");
											System.out.println("");
											System.out
													.println("Enter New Address");
											String addr = scanner.next();
											System.out
													.println("Enter New Mobile Number");
											number = scanner.next();

											// Validating the mobile number
											if (number.length() == 10) {
												num = number.matches("[0-9]+");
												if (num == true) {
													n = serviceUser
															.changeInCommunicationAddress(
																	userid,
																	addr,
																	number);
													logger.info(n
															+ " row updated");
													System.out.println(n
															+ " row updated");
													System.out
															.println("************************************************");
													System.out.println("");
												} else {
													logger.error("Please enter only number");
													System.out
															.println("Please enter only Number:");
												}

											} else {
												logger.error("Please enter 10 digit number");
												System.out
														.println("Please enter 10 digit number:");
											}

										} while (number.length() != 10
												|| num == false);
										break;

									case 2:
										// Requesting for cheaque book
										String desc = "";
										System.out.println("Enter desc");
										desc = scanner.next();
										logger.info("Your request for cheaque book is generated");
										System.out
												.println("Your request for cheaque book is generated and "
														+ "the service_id is "
														+ serviceUser
																.chequeBookRequest(
																		userid,
																		desc));
										System.out
												.println("************************************************");
										System.out.println("");
										break;

									case 3:
										// Tracking the service id request, if
										// generated
										int sid = 0;
										String status = "";
										do {
											System.out
													.println("Enter Your Serviceid:");
											sid = scanner.nextInt();
											BankUser bankUser1 = new BankUser();
											bankUser1.setServiceId(sid);
											bankUser1.setUserName(userid);
											status = serviceUser
													.trackServiceRequest(bankUser1);

											if (status != null) {
												logger.info("Status is: "
														+ status);
												System.out
														.println("Status is: "
																+ status);
												System.out
														.println("************************************************");
												System.out.println("");
											}
											if (status == null) {
												System.out
														.println("Please enter your service tracker ID");
											}
										} while (status != null);
										break;

									case 4:
										long transferAmount = 0;
										int payeeAccount_id = 0;
										BankUser bankUser2 = new BankUser();

										System.out
												.println("Enter Payee Account Id :");
										payeeAccount_id = scanner.nextInt();
										bankUser2
												.setPayeeAccount(payeeAccount_id);

										System.out
												.println("Enter Amount to be transfered:");
										transferAmount = scanner.nextInt();
										bankUser2
												.setTransferAmount(transferAmount);

										System.out
												.println("Enter Transaction Password:");
										String transaction_Password = scanner.next();
										bankAdmin
												.setTransactionpassword(transaction_Password);

										n = serviceUser.fundTransfer(userid,
												bankUser2, bankAdmin);
										logger.info(n + " rows updated");
										System.out
												.println(n + " Rows Updated.");
										break;

									case 5:
										// Displaying the change of password
										// procedure
										String newpassword1 = "";
										System.out
												.println("Enter old Password:");
										oldpassword = scanner.next();
										System.out
												.println("Enter new Password:");
										newpassword = scanner.next();
										System.out
												.println("Confirm new Password:");
										newpassword1 = scanner.next();

										if (newpassword1.equals(newpassword)
												&& oldpassword.equals(pass)) {
											userid = bankUser.getUserName();
											n = serviceUser.changePassword(
													newpassword, userid);
											logger.info(n + " rows updated");
											System.out.println(n
													+ " Row Updated.");
											System.out
													.println("************************************************");
											System.out.println("");
										} else {
											logger.error("Password didn't match");
											System.out
													.println("Password didn't match");
										}
										break;

									case 6:
										System.out
												.println("Select Statement Duration:");
										System.out
												.println("1. Press 1 for Weekly(Mini) Statement");
										System.out
												.println("2. Press 2 for Monthly(Detailed) Statement");
										System.out
												.println("3. Press 3 for Yearly(Detailed) Statement");
										System.out.println("");
										System.out
												.println("************************************************");
										int duration = scanner.nextInt();
										int tranDuration = 0;
										switch (duration) {
										case 1:
											tranDuration = 10;
											break;

										case 2:
											tranDuration = 30;
											break;

										case 3:
											tranDuration = 365;
											break;
										}
										ArrayList<BankUser> arrayList = new ArrayList<BankUser>();
										arrayList = serviceUser
												.viewMiniStatement(userid,
														tranDuration);

										System.out
												.println("Transaction_ID | Tran_Description | DateofTransaction | "
														+ "TransactionType |  TranAmount  |  Account_No");
										System.out
												.println("----------------------------------------------------------"
														+ "------------------------------------------");
										for (BankUser bankUser3 : arrayList) {
											System.out
													.println(bankUser3
															.getTransaction_ID()
															+ " 		|	"
															+ bankUser3
																	.getTran_Description()
															+ "	 |	"
															+ bankUser3
																	.getDateofTransaction()
															+ "	|	"
															+ bankUser3
																	.getTransactionType()
															+ "	 |	"
															+ bankUser3
																	.getTransferAmount()
															+ "  	|	"
															+ bankUser3
																	.getAccountId());
										}

										break;

									default:
										logger.info("Thank you for visiting");
										System.out
												.println("Thanks for Visiting");

										break;
									}
									logger.info("Press 'Y' to continue and 'N' to exit");
									System.out
											.println("Press 'Y' to continue and 'N' to exit");
									j = scanner.next().charAt(0);
								} while (j == 'Y' || j == 'y');

							}

							// Admin login is done and can do following tasks.
							else if (serviceUser.login(userid, pass) == 1) {
								char j = 'N';
								do {
									System.out.println("Login is successful");
									System.out
											.println("************************************************");
									System.out.println("");
									System.out
											.println("1. Create New Account:");
									System.out
											.println("2. View transactions of all accounts:");
									System.out.println("");
									System.out
											.println("************************************************");
									System.out.println("");
									System.out.println("Select the service");
									i = scanner.nextInt();

									switch (i) {
									case 1:
										// Creation of bank account of new user
										boolean num = false,
										email = false,
										balance = false;
										String customerName = "",
										customerEmail = "",
										customerAddress = "",
										mobileNumber = "";
										System.out.println("Enter Your name");
										customerName = scanner.next();

										// Validating the Email id given
										do {
											System.out
													.println("Enter your email");
											customerEmail = scanner.next();
											String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."
													+ "[a-zA-Z0-9_+&*-]+)*@"
													+ "(?:[a-zA-Z0-9-]+\\.)+[a-z"
													+ "A-Z]{2,7}$";

											if (customerEmail == null) {
												logger.error("Please enter email id");
												System.out
														.println("Please enter email id");
											} else {
												Pattern pattern = Pattern
														.compile(emailRegex);
												email = pattern.matcher(
														customerEmail)
														.matches();
												if (email == true) {

												} else {
													logger.error("Invalid email-id");
													System.out
															.println("Enter valid email id");
													System.out.println("");
												}
											}
										} while (email == false);

										System.out
												.println("Enter Your Address");
										customerAddress = scanner.next();

										// validating the mobile number provided
										do {

											System.out
													.println("Enter Your Mobile number");
											mobileNumber = scanner.next();
											if (mobileNumber.length() == 10) {
												num = mobileNumber
														.matches("[0-9]+");
												if (num == true) {

												} else {
													logger.error("Please enter only number:");
													System.out
															.println("Please enter only number:");
													System.out.println("");
												}

											} else {
												logger.error("Please enter 10 digit number:");
												System.out
														.println("Please enter 10 digit number:");
												System.out.println("");
											}
										} while (mobileNumber.length() != 10
												|| num == false);

										bankAdmin.setCustomerName(customerName);
										bankAdmin
												.setCustomeremail(customerEmail);
										bankAdmin
												.setCustomeraddress(customerAddress);
										bankAdmin.setMobileNumber(mobileNumber);

										String accountType = "";
										int openingBalance;
										System.out
												.println("Enter account_type");
										accountType = scanner.next();

										do {
											System.out
													.println("Enter Opening balance");
											openingBalance = scanner.nextInt();

											if (openingBalance < 0) {
												logger.error("Invalid amount");
												System.out
														.println("Invalid amount");
												System.out.println("");
												balance = false;
											} else {
												balance = true;
											}

										} while (balance == false);

										bankAdmin.setAccountType(accountType);
										bankAdmin
												.setOpeningBalance(openingBalance);

										String securityQuestion = "",
										securityAnswer = "";
										System.out
												.println("Enter Security question and answer");
										securityQuestion = scanner.next();
										securityAnswer = scanner.next();
										bankAdmin
												.setSecurityQuestion(securityQuestion);
										bankAdmin
												.setSecurityAnswer(securityAnswer);

										int account_id = serviceAdmin
												.createNewAccount(bankAdmin);
										System.out
												.println("Account is created");
										System.out
												.println("Your Account Id is "
														+ account_id);
										break;

									case 2:
										String accountid1 = "";
										int duration = 0,
										account_id1 = 0;
										System.out
												.println("Enter Account Id for getting Transaction of accountid");

										do {
											accountid1 = scanner.next();
											if (accountid1
													.matches("[1-9]{1}[0-9]+")) {

												account_id1 = Integer
														.parseInt(accountid1);
												System.out
														.println("Select Duration:");
												System.out.println("1. Weekly");
												System.out
														.println("2. Monthly");
												System.out.println("3. Yearly");

												duration = scanner.nextInt();
												int tranDuration = 0;

												switch (duration) {
												case 1:
													tranDuration = 7;
													break;

												case 2:
													tranDuration = 30;
													break;

												case 3:
													tranDuration = 365;
													break;

												default:
													System.out
															.println("Please select proper duration.");
													break;
												}

												ArrayList<BankUser> arrayList1 = new ArrayList<BankUser>();
												arrayList1 = serviceAdmin
														.viewTransaction(
																account_id1,
																tranDuration);

												if (arrayList1.isEmpty()) {
													System.err
															.println("Sorry, There is no transaction to display.");

												} else {
													System.out
															.println("Transaction_ID | Tran_Description | DateofTransaction | "
																	+ "TransactionType |  TranAmount  |  Account_No");
													System.out
															.println("----------------------------------------------------------"
																	+ "------------------------------------------");
													for (BankUser bank : arrayList1) {
														System.out
																.println(bank
																		.getTransaction_ID()
																		+ " 		|	"
																		+ bank.getTran_Description()
																		+ "	 |	"
																		+ bank.getDateofTransaction()
																		+ "	|	"
																		+ bank.getTransactionType()
																		+ "	 |	"
																		+ bank.getTransferAmount()
																		+ "  	|	"
																		+ account_id1);
													}
												}
											} else {
												logger.error("Please enter account number in digits only.");
												System.out
														.println("Please enter account number in digits only.");
											}

										} while (!accountid1
												.matches("[1-9]{1}[0-9]+"));
										break;

									default:
										System.out
												.println("Thanks for Visiting");
										System.out
												.println("************************************************");
										System.out.println("");
										System.out
												.println("************************************************");
										break;
									}

									System.out
											.println("Press 'Y' to continue and 'N' to exit");
									j = scanner.next().charAt(0);
								} while (j == 'Y' || j == 'y');

							} else {
								++count;
								int left = 3 - count;

								if (count < 3) {
									System.out
											.println("Incorrect Username or Password.");
									System.out
											.println("You have entered Wrong UserName and Password "
													+ count + " Time.");
									System.out.println("You have " + left
											+ " attempts left.");
									System.out.println("");
									System.out
											.println("************************************************");
									System.out.println("");
									System.out
											.println("Please enter correct UserName and Password.");
								}
								if (count == 3) {
									System.out
											.println("Your Account is locked. Please Contact to Home Branch.");
									System.out
											.println("************************************************");
								}

							}
						} catch (OnlineBankingException e) {
							logger.error("Incorrect details provided");
							throw new OnlineBankingException("problem : "
									+ e.getMessage());
						}

					} while (count > 0 && count < 3);
					break;

				default:
					logger.error("wrong input");
					System.out.println("Wrong Input");
					System.out
							.println("************************************************");
					break;
				}
			} catch (OnlineBankingException e) {
				logger.error("Incorrect details provided");
				throw new OnlineBankingException("problem : " + e.getMessage());
			}
		} while (count == 0);
	}

	public String toString() {
		return null;

	}
}
