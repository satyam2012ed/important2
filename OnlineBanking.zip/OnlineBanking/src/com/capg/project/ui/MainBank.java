package com.capg.project.ui;

/*
 * Author by Kumar Satyam
 * Last modified on 07 Sep 2018 
 */

import java.util.*;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.BankAdmin;
import com.capg.project.bean.BankUser;
import com.capg.project.service.AdminBankServiceImpl;
import com.capg.project.service.IAdminBankService;
import com.capg.project.service.IUserBankService;
import com.capg.project.service.UserBankServiceImpl;

public class MainBank {
	static int count = 0;

	public static void main(String[] args) throws OnlineBankingException {

		Logger logger = Logger.getLogger("MyLogger");

		BankUser bankUser = new BankUser();
		BankAdmin bankAdmin = new BankAdmin();
		IUserBankService serviceUser = new UserBankServiceImpl();
		IAdminBankService serviceAdmin = new AdminBankServiceImpl();

		int i, flag;
		String newpassword;
		String oldpassword;
		String pass, userid;
		int n = 0;

		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		System.out.println("");
		System.out.println("------------------------------------------------");
		System.out.println("|           Welcome to Online Banking          |");
		System.out.println("------------------------------------------------");
		System.out.println("");

		do {	
			System.out.println("Login Page");
			System.out.println("------------------------------------------------");
			System.out.println("Enter Id:");
			userid = scanner.next();
			bankUser.setUserName(userid);
			System.out.println("Enter Password:");
			pass = scanner.next();
			bankUser.setPassword(pass);

			try {
						/* User login is done and can do listed service */
				if (serviceUser.login(userid, pass) == 0) {
				System.out.println("User login is successful");
				char j = 'N';
				do {
					boolean flag5=true;
									
					try {																	
						System.out.println("************************************************");
						System.out.println("");
						System.out.println("1. Change In Communication Address:");
						System.out.println("2. Request For Cheaque Book:");
						System.out.println("3. Track  Service Request:");
						System.out.println("4. Fund Transfer:");
						System.out.println("5. Change Password:");
						System.out.println("6. Mini Statement:");
						System.out.println("");
						System.out.println("************************************************");
						System.out.println("");
						do {		
							System.out.println("Select your service: ");
							i = scanner.nextInt();																		
									
							for(int k=1;k<=6;k++) {
								if(i!=k) {										
									flag5=false;										
								}
								else {
									flag5=true;
									break;
								}									
							}
							if(flag5==false) {
								logger.error("Inalid input");
								System.err.println("Invalid input");
							}
						} while(flag5==false);
									
						System.out.println("************************************************");
						System.out.println("");

						switch (i) {
								/* Displaying and changing the communication
									 address */
							case 1:
									String number = "";
									boolean num = false;
									System.out.println("Your Communication Address is:");
									serviceUser.changeInCommunicationAddress(userid);
									
									System.out.println("************************************************");
									System.out.println("");
									System.out.println("Enter New Address");
									String addr = scanner.next();
									do {
										System.out.println("Enter New Mobile Number");
										number = scanner.next();

											// Validating the mobile number
										if (number.length() == 10) {
											num = number.matches("[0-9]+");
											if (num == true) {
												n = serviceUser.changeInCommunicationAddress(userid,addr,number);
												logger.info(n+ " row updated");
												System.out.println(n+ " row updated");
												System.out.println("************************************************");
												System.out.println("");
											} else {
													logger.error("Please enter only number");
													System.err.println("Please enter only Number:");
												}

										} else {
											logger.error("Please enter 10 digit number");
											System.out.println("Please enter 10 digit number:");
										}

									} while (number.length() != 10 || num == false);
								break;

							case 2:
									/* Calling the cheaque book request 
										 method in service layer */
									String desc = "";
										
									logger.info("Your request for cheaque book is generated");
									System.out.println("Your request for cheaque book is generated and "
												+ "the service_id is " + serviceUser.chequeBookRequest(userid,desc));
									System.out.println("************************************************");
									System.out.println("");
								break;

							case 3:
									/* Calling the track Service request 
									 * method in service layer of user
									 * to track for service status */
									int sid = 0;
									String status = "";
									do {
										System.out
												.println("Enter Your Service Id:");
										sid = scanner.nextInt();
										BankUser bankUser1 = new BankUser();
										bankUser1.setServiceId(sid);
										bankUser1.setUserName(userid);
										status = serviceUser.trackServiceRequest(bankUser1);

										if (status != null) {
											logger.info("Status is: "+ status);
											System.out.println("Status is: "+ status);
											System.out.println("************************************************");
											System.out.println("");
											status = null;
										}
										else if (status == null) {
											logger.error("Wrong service id");
											System.out.println("Wrong service tracker ID");
											System.out.println("************************************************");
											status = "";
										}
									} while (status != null);
								break;

							case 4:
									/* Storing the values in BankUser bean class 
									 * and Calling the fund transfer method 
									 * in service layer of user to do transaction */
									long transferAmount = 0;
									int payeeAccount_id = 0;
									BankUser bankUser2 = new BankUser();

									System.out.println("Enter Payee Account Id :");
									payeeAccount_id = scanner.nextInt();
									bankUser2.setPayeeAccount(payeeAccount_id);

									System.out.println("Enter Amount to be transfered:");
									transferAmount = scanner.nextInt();
									bankUser2.setTransferAmount(transferAmount);

									System.out.println("Enter Transaction Password:");
									String transaction_Password = scanner.next();
									bankAdmin.setTransactionpassword(transaction_Password);

									n = serviceUser.fundTransfer(userid,bankUser2, bankAdmin);
									logger.info(n + " rows updated");
									System.out.println(n + " Rows Updated.");
									System.out.println("************************************************");
									System.out.println("");
								break;

							case 5:
									/* Calling the change of password procedure
									 * in service layer using both old password
									 *  and new password for validation  */
									boolean flag2 =true;
									do {
										String newpassword1 = "";
										
										System.out.println("Enter old Password:");
										oldpassword = scanner.next();
										if(oldpassword.equals(pass)) {																
											System.out.println("Enter new Password:");
											newpassword = scanner.next();
											System.out.println("Confirm new Password:");
											newpassword1 = scanner.next();

											if (newpassword1.equals(newpassword) && oldpassword.equals(pass)) {										
												userid = bankUser.getUserName();
												n = serviceUser.changePassword(newpassword, userid);
												logger.info(n + " rows updated");
												System.out.println(n+ " Row Updated.");
												System.out.println("************************************************");
												System.out.println("");											
											} else {
											logger.error("Password didn't match");
											System.out.println("Password didn't match");
											}
										} else {
											System.out.println("Wrong current password");
											flag2 =false;
											}
									} while(flag2==false);
								break;
								
							case 6:
									/* It calls mini statement method in service layer
									 * for getting the statement of week, month or year */
									System.out.println("Select Statement Duration:");
									System.out.println("1. For Weekly Statement");
									System.out.println("2. For Monthly Statement");
									System.out.println("3. For Yearly Statement");
									System.out.println("");
									System.out.println("************************************************");
									
									try {
									int tranDuration = 0;
									do {
										System.out.println("Enter your choice");
										int duration = scanner.nextInt();
																				
										switch (duration) {
										case 1:
											tranDuration = 10;
											break;

										case 2:
											tranDuration = 30;
											break;

										case 3:
											tranDuration = 365;
											break;
										
										default:
											logger.error("Invalid choice");
											System.out.println("Invalid choice");
											System.out.println("************************************************");
											System.out.println("");												
											break;
										} 								
									} while(tranDuration==0);
									
									ArrayList<BankUser> arrayList = new ArrayList<BankUser>();
									arrayList = serviceUser.viewMiniStatement(userid,tranDuration);
									
									System.out.println("************************************************");
									System.out.println("");	
									System.out.println("Transaction_ID | Tran_Description | DateofTransaction | "
														+ "TransactionType |  TranAmount  |  Account_No");
									System.out.println("----------------------------------------------------------"
														+ "------------------------------------------");
									for (BankUser bankUser3 : arrayList) {
										System.out.println(bankUser3
													.getTransaction_ID()
													+ " 		|	"
													+ bankUser3
															.getTran_Description()
													+ "	 |	"
													+ bankUser3
															.getDateofTransaction()
													+ "	|	"
													+ bankUser3
															.getTransactionType()
													+ "	 |	"
													+ bankUser3
															.getTransferAmount()
													+ "  	|	"
													+ bankUser3
															.getAccountId());
									}
									System.out.println("");	
									System.out.println("*****************************************************************************************************");
									System.out.println("");	
									}catch(InputMismatchException e) {
										System.out.println("Enter number only");
									}
								break;
								

							default:
									logger.info("Invalid choice");
									System.out.println("Invalid choice");
									break;
						}
																		
					} catch (InputMismatchException e) {
						logger.error("Enter only number");
						System.out.println("Enter only number");
						System.out.println("************************************************");
						}
																
					boolean flag1 = false;
					System.out.println("Press 'Y' to continue and 'N' to exit");
									
					do {																	
									
						j = scanner.next().charAt(0);																		
						if(j=='y' || j=='Y' || j=='n' || j=='N') {
								flag1 = true;
						}
					} while(flag1 == false);
									
					System.out.println("");									
					} while (j == 'Y' || j == 'y');

				}

					/* Admin login is done and can do following tasks */
				else if (serviceUser.login(userid, pass) == 1) {								
				System.out.println("Admin login is successful");
				
				char j = 'N';
				do {
					try {
						System.out.println("************************************************");
						System.out.println("");
						System.out.println("1. Create New Account:");
						System.out.println("2. View transactions of all accounts:");
						System.out.println("");
						System.out.println("************************************************");
						System.out.println("");
						System.out.println("Select the service");
						i = scanner.nextInt();
						System.out.println("************************************************");
						System.out.println("");
									
						switch (i) {
						
							case 1:
									/* Storing the user's name, email, mobile number,
									 * address, account_type, opening balance, security
									 * question and security answer into BankAdmin bean
									 * class and requesting for creating a new account for
									 * particular user in service layer of admin */
								boolean num = false,
								email = false,
								balance = false,
								name =false;
										
								String customerName = "", customerEmail = "", customerAddress = "", mobileNumber = "";
										
								
									System.out.println("Enter Your name");
									customerName = scanner.next();
																															
									// Validating the Email id given
									do {
										System.out.println("Enter your email");
										customerEmail = scanner.next();
										String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."
													+ "[a-zA-Z0-9_+&*-]+)*@"
													+ "(?:[a-zA-Z0-9-]+\\.)+[a-z"
													+ "A-Z]{2,7}$";

										if (customerEmail == null) {
											logger.error("Please enter email id");
											System.out.println("Please enter email id");
										} else {
												Pattern pattern = Pattern.compile(emailRegex);
												email = pattern.matcher(customerEmail).matches();
												if (email == true) {
												} else {
													logger.error("Invalid email-id");
													System.out.println("Enter valid email id");
													System.out.println("");
												}
											}
									} while (email == false);																	
								
								System.out.println("Enter Your Address");
								customerAddress = scanner.next();

										// validating the mobile number provided
								do {
									System.out.println("Enter Your Mobile number");
									mobileNumber = scanner.next();
									
									if (mobileNumber.length() == 10) {
										num = mobileNumber.matches("[0-9]+");
										if (num == true) {
										} else {
												logger.error("Please enter only number");
												System.out.println("Please enter only number");
												System.out.println("");
											}

									} else {
										logger.error("Please enter 10 digit number");
										System.out.println("Please enter 10 digit number");
										System.out.println("");
									}
								} while (mobileNumber.length() != 10 || num == false);

								bankAdmin.setCustomerName(customerName);
								bankAdmin.setCustomeremail(customerEmail);
								bankAdmin.setCustomeraddress(customerAddress);
								bankAdmin.setMobileNumber(mobileNumber);

								String accountType = "";
								int openingBalance;
								System.out.println("Enter account_type");
								accountType = scanner.next();

								do {
									System.out.println("Enter Opening balance");
									openingBalance = scanner.nextInt();

									if (openingBalance < 0) {
										logger.error("Invalid amount");
										System.err.println("Invalid amount");
										System.out.println("");
										balance = false;
									} else {
											balance = true;
										}

								} while (balance == false);

								bankAdmin.setAccountType(accountType);
								bankAdmin.setOpeningBalance(openingBalance);

								String securityQuestion = "",
								securityAnswer = "";
								System.out.println("Enter Security Question");
								securityQuestion = scanner.next();
								System.out.println("Enter Security Answer");
								securityAnswer = scanner.next();
								bankAdmin.setSecurityQuestion(securityQuestion);
								bankAdmin.setSecurityAnswer(securityAnswer);

								int account_id = serviceAdmin.createNewAccount(bankAdmin);
								System.out.println("Account is created");
								System.out.println("Your Account Id is "+ account_id);
								System.out.println("");
								System.out.println("************************************************");
								System.out.println("");
							break;

							case 2:
								/* It calls view transaction method for getting
								 * transaction details of user based on
								 * week, month or year in service layer of admin  */
								try {
								String accountid1 = "";
								int duration = 0,
								account_id1 = 0;
								System.out.println("Enter Account Id for getting transaction details");

								do {									
									accountid1 = scanner.next();
									System.out.println("************************************************");
									System.out.println("");
									
									if (accountid1.matches("[1-9]{1}[0-9]+")) {
										account_id1 = Integer.parseInt(accountid1);
												
										System.out.println("1. Weekly");
										System.out.println("2. Monthly");
										System.out.println("3. Yearly");
												
										int tranDuration = 0;
										do {
											
											System.out.println("Select Duration:");
											
											duration = scanner.nextInt();
											System.out.println("********************************************************************************************************");
											System.out.println("");
												
											switch (duration) {
												case 1:
													tranDuration = 7;
													break;

												case 2:
													tranDuration = 30;
													break;

												case 3:
													tranDuration = 365;
													break;

												default:
													logger.error("Invalid duration");
													System.out.println("Invalid duration.");
													break;
												}																						
										} while(tranDuration == 0);
												
										ArrayList<BankUser> arrayList1 = new ArrayList<BankUser>();
										arrayList1 = serviceAdmin.viewTransaction(account_id1,tranDuration);

										if (arrayList1.isEmpty()) {
											logger.error("There is no transaction for this account id");
											System.out.println("There is no transaction for this account id");
											System.out.println("************************************************");
										} else {
											System.out.println("Transaction_ID | Tran_Description | DateofTransaction | "
															+ "TransactionType |  TranAmount  |  Account_No");
											System.out.println("----------------------------------------------------------"
															+ "------------------------------------------");
											
											for (BankUser bank : arrayList1) {
												System.out.println(bank
														.getTransaction_ID()
														+ " 		|	"
														+ bank.getTran_Description()
														+ "	 |	"
														+ bank.getDateofTransaction()
														+ "	|	"
														+ bank.getTransactionType()
														+ "	 |	"
														+ bank.getTransferAmount()
														+ "  	|	"
														+ account_id1);
											}
											System.out.println("");
											System.out.println("******************************************************************************************************");
										}
									} else {
										logger.error("Please enter account number in digits only.");
										System.out.println("Please enter account number in digits only.");
										}

								  } while (!accountid1.matches("[1-9]{1}[0-9]+"));
								
								} catch(InputMismatchException e) {
									logger.error("Enter number only");
									System.out.println("Enter number only");
									}
									break;

							default:
								logger.error("error in choosing the admin service");
								System.out.println("Invalid choice");
								System.out.println("");
								System.out.println("************************************************");										
								break;
						}
					} catch(InputMismatchException e) {
							logger.error("Enter only number");
							System.err.println("Enter only number");
						}
																		
					boolean flag1=false;
					System.out.println("Press 'Y' to continue and 'N' to exit");
								
					do {																
						j = scanner.next().charAt(0);
									
						if(j=='y' || j=='Y' || j=='n' || j=='N') {
								flag1 = true;
							}
					} while(flag1 == false);
									
					System.out.println("");
									
				} while (j == 'Y' || j == 'y');

			} else {				
					logger.error("Incorrect username and password");
					System.out.println("Incorrect Username or Password.");

					System.out.println("Please enter correct UserName and Password.");
					System.out.println("************************************************");
					System.out.println("");					
				}
		} catch (OnlineBankingException e) {
				logger.error("Incorrect details provided");
				throw new OnlineBankingException("problem : "+ e.getMessage());
			}

	} while (count >= 0 && count < 3);    //redirecting to login page
  }	
}
