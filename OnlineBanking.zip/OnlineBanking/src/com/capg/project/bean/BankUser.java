package com.capg.project.bean;

/*
 * Author by Kumar Satyam
 * Last modified on 10 Sep 2018 
 */

import java.util.Date;

public class BankUser {
	private int transaction_ID ;
	private String tran_Description;
	private Date dateofTransaction ;
	private String transactionType;
	private int accountId;
	private long transferAmount;
	private int balance;
	private String cusName;
	private String cusAddr;
	private String mobileNumber;
	private String Service_Description;
	private String userName;
	private String password;
	private int payeeAccount;
	private String nickName;
	private int serviceId;

	
	/* Getter and setter method for all the above declared variables. */ 
	 public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	
	public int getTransaction_ID() {
		return transaction_ID;
	}
	public void setTransaction_ID(int transaction_ID) {
		this.transaction_ID = transaction_ID;
	}
	
	public String getTran_Description() {
		return tran_Description;
	}
	public void setTran_Description(String tran_Description) {
		this.tran_Description = tran_Description;
	}
	
	public Date getDateofTransaction() {
		return dateofTransaction;
	}
	public void setDateofTransaction(Date dateofTransaction) {
		this.dateofTransaction = dateofTransaction;
	}
	
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	
	public String getNickname() {
		return nickName;
	}
	public void setNickname(String nickname) {
		this.nickName = nickname;
	}
		 	 
	public int getPayeeAccount() {
		return payeeAccount;
	}
	public void setPayeeAccount(int payeeAccount) {
		this.payeeAccount = payeeAccount;
	}
	
	public long getTransferAmount() {
		return transferAmount;
	}
	public void setTransferAmount(long transferAmount) {
		this.transferAmount = transferAmount;
	}
	
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userid) {
		this.userName = userid;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getCusname() {
		return cusName;
	}
	public void setCusname(String cusname) {
		this.cusName = cusname;
	}
	
	public String getCusaddr() {
		return cusAddr;
	}
	public void setCusaddr(String cusaddr) {
		this.cusAddr=cusaddr;
	}
	
	public int getBal() {
		return balance;
	}
	public void setBal(int balance) {
		this.balance = balance;
	}
	
	public BankUser() {
		
	}
	
	public BankUser(String cusaddr, String mobileNumber) {
		super();
		this.cusAddr = cusaddr;
		this.mobileNumber = mobileNumber;
	}
	
	/* Argument constructor*/
	public BankUser(int cusid, int balance, String cusname, String cusaddr,
			String mobileNumber, String service_Description, String userName,
			String password) {
		super();
		this.accountId = accountId;
		this.balance = balance;
		this.cusName = cusname;
		this.cusAddr = cusaddr;
		this.mobileNumber = mobileNumber;
		Service_Description = service_Description;
		this.userName = userName;
		this.password = password;
	}
	
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String MobileNumber) {
		this.mobileNumber = MobileNumber;
	}
	
	public String getService_Description() {
		return Service_Description;
	}
	public void setService_Description(String service_Description) {
		Service_Description = service_Description;
	}
	
	public void setTranDuration(int tranDuration) {		
	}
	public int getTranDuration() {		
		return 0;
	}
	public void setCusid(int accountId2) {
		
		
	}
}
