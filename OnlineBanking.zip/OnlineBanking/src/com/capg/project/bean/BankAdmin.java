package com.capg.project.bean;

/*
 * Author by Kumar Satyam
 * Last modified on 08 Sep 2018 
 */

public class BankAdmin {

	public BankAdmin() {		
	}
	
	String accountType;
	int openingBalance;
	private String customerName;
	private String mobileNumber;
	private String customerEmail;
	private String customerAddress;
	private int userId ;
	private String loginPassword;
	private String transactionPassword;
	private String securityAnswer;
	private String securityQuestion;
	
	/* Getter and setter method for the above variables */
	public String getTransactionpassword() {
		return transactionPassword;
	}
	public void setTransactionpassword(String transactionpassword) {
		this.transactionPassword = transactionpassword;
	}
	
	public String getSecurityAnswer() {
		return securityAnswer;
	}
	public void setSecurityAnswer(String securityAnswer) {
		this.securityAnswer = securityAnswer;
	}
	
	public String getSecurityQuestion() {
		return securityQuestion;
	}
	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}
	
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	
	public int getOpeningBalance() {
		return openingBalance;
	}
	public void setOpeningBalance(int openingBalance) {
		this.openingBalance = openingBalance;
	}
	
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public String getCustomeremail() {
		return customerEmail;
	}
	public void setCustomeremail(String customeremail) {
		this.customerEmail = customeremail;
	}
	
	public String getCustomeraddress() {
		return customerAddress;
	}
	public void setCustomeraddress(String customeraddress) {
		this.customerAddress = customeraddress;
	}
	
	public int getUserid() {
		return userId;
	}
	public void setUserid(int userid) {
		this.userId = userid;
	}
	
	public String getLoginpassword() {
		return loginPassword;
	}
	public void setLoginpassword(String loginpassword) {
		this.loginPassword = loginpassword;
	}
}
