package com.capg.project.service;

import java.util.ArrayList;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.BankAdmin;
import com.capg.project.bean.BankUser;
import com.capg.project.dao.IUserBankDAO;
import com.capg.project.dao.UserBankDAOImpl;

public class UserBankServiceImpl implements IUserBankService {
	BankUser bankUser =new BankUser();
	IUserBankDAO dao=new UserBankDAOImpl();
	@Override
	public int login(String userid,String password)
			throws OnlineBankingException {		
		return dao.login(userid, password);
	}

	@Override
	public int changeInCommunicationAddress(String userid)
			throws OnlineBankingException {		
		return dao.changeInCommunicationAddress(userid);
	}
	public int changeInCommunicationAddress(String userid,String address,String number) throws OnlineBankingException {
		return dao.changeInCommunicationAddress(userid,address,number);
		
	}

	@Override
	public int chequeBookRequest(String userid,String description) throws OnlineBankingException {
		return dao.chequeBookRequest(userid,description);
	}

	@Override
	public String trackServiceRequest(BankUser bankUser)
			throws OnlineBankingException {
		return dao.trackServiceRequest(bankUser);
		
	}

	@Override
	public int fundTransfer(String userid,BankUser bankUser1,BankAdmin bankAdmin) throws OnlineBankingException {		
		return dao.fundTransfer(userid,bankUser1,bankAdmin);
	}

	@Override
	public int changePassword(String newPassword,String userid) throws OnlineBankingException {	
		return dao.changePassword(newPassword,userid);
	}

	@Override
	public ArrayList<BankUser> viewMiniStatement(String userid,int tranDuration) throws OnlineBankingException {
		ArrayList<BankUser> arrayList = new ArrayList<BankUser>();
		arrayList = dao.viewMiniStatement(userid,tranDuration);
		
		return arrayList;
	}

	

}
