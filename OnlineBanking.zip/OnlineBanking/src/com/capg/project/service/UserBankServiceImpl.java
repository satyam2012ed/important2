package com.capg.project.service;

/*
 * Author by Kumar Satyam
 * Last modified on 08 Sep 2018 
 */

import java.util.ArrayList;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.BankAdmin;
import com.capg.project.bean.BankUser;
import com.capg.project.dao.IUserBankDAO;
import com.capg.project.dao.UserBankDAOImpl;

public class UserBankServiceImpl implements IUserBankService {
	BankUser bankUser =new BankUser();
	IUserBankDAO dao = null;
//	IUserBankDAO dao=new UserBankDAOImpl();

	
	/*
	 * This method receives userid and password from user
	 * or admin interface and passes it
	 * to DAO layer to check whether person is "user" or "admin"
	 */
	@Override
	public int login(String userid,String password) throws OnlineBankingException {	
		dao=new UserBankDAOImpl();
		return dao.login(userid, password);
	}

	
	/*
	 * This method receives user id from user interface and passes it
	 * to DAO layer to display the current communication address
	 */
	@Override
	public int changeInCommunicationAddress(String userid) throws OnlineBankingException {	
		dao=new UserBankDAOImpl();
		return dao.changeInCommunicationAddress(userid);
	}
	/*
	 * This method receives user id, address and mobile number
	 * from user interface and passes it to DAO layer to change
	 * the current communication address by providing new one.
	 */
	public int changeInCommunicationAddress(String userid,String address,String number) throws OnlineBankingException {
		dao=new UserBankDAOImpl();
		return dao.changeInCommunicationAddress(userid,address,number);
		
	}

	
	/*
	 * This method receives user id and description from user interface
	 * and passes it to DAO layer to request for new cheque book.
	 */
	@Override
	public int chequeBookRequest(String userid,String description) throws OnlineBankingException {
		dao=new UserBankDAOImpl();
		return dao.chequeBookRequest(userid,description);
	}

	
	/*
	 * This method receives object from user interface and passes
	 * it to DAO layer to track the service requested by user
	 */
	@Override
	public String trackServiceRequest(BankUser bankUser) throws OnlineBankingException {
		dao=new UserBankDAOImpl();
		return dao.trackServiceRequest(bankUser);
		
	}

	
	/*
	 * This method receives user id, object from user interface and
	 * object from admin interface passes it to DAO layer to do the
	 * fund transfer process.
	 */
	@Override
	public int fundTransfer(String userid,BankUser bankUser1,BankAdmin bankAdmin) throws OnlineBankingException {
		dao=new UserBankDAOImpl();
		return dao.fundTransfer(userid,bankUser1,bankAdmin);
	}

	
	/*
	 * This method receives user id and new password entered by the user 
	 * and passes it to DAO layer to change the password.
	 */
	@Override
	public int changePassword(String newPassword,String userid) throws OnlineBankingException {
		dao=new UserBankDAOImpl();
		return dao.changePassword(newPassword,userid);
	}

	
	/*
	 * This method receives user id and transaction duration time
	 * and passes it to DAO layer to display the mini statement details.
	 */
	@Override
	public ArrayList<BankUser> viewMiniStatement(String userid,int tranDuration) throws OnlineBankingException {
		dao=new UserBankDAOImpl();
		ArrayList<BankUser> arrayList = new ArrayList<BankUser>();
		arrayList = dao.viewMiniStatement(userid,tranDuration);		
		return arrayList;
	}

	

}
