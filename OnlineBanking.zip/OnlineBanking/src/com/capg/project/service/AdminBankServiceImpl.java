package com.capg.project.service;

/*
 * Author by Kumar Satyam
 * Last modified on 10 Sep 2018 
 */

import java.util.ArrayList;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.BankAdmin;
import com.capg.project.bean.BankUser;
import com.capg.project.dao.AdminBankDAOImpl;
import com.capg.project.dao.IAdminBankDAO;

public class AdminBankServiceImpl implements IAdminBankService {
	IAdminBankDAO admindao = null;
//	IAdminBankDAO admindao=new AdminBankDAOImpl();
	
	/*
	 * This method receives object from admin interface and passes it
	 * to DAO layer to create a new account
	 */
	@Override
	public int createNewAccount(BankAdmin bankAdmin) throws OnlineBankingException {
		admindao = new AdminBankDAOImpl(); 
		return admindao.createNewAccount(bankAdmin);
	}
	
	/*
	 * This method receives object from admin interface and passes it
	 * to DAO layer to view the transaction details
	 */
	@Override
	public ArrayList<BankUser> viewTransaction(int account_id, int tranDuration) throws OnlineBankingException {
		admindao = new AdminBankDAOImpl(); 
		return admindao.viewTransaction(account_id,tranDuration);
	}
}
