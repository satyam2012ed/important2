package com.capg.project.service;

import java.util.ArrayList;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.BankAdmin;
import com.capg.project.bean.BankUser;

public interface IAdminBankService {
	public int createNewAccount(BankAdmin bankAdmin) throws OnlineBankingException;
	 public ArrayList<BankUser> viewTransaction(int account_id,int tranDuration) throws OnlineBankingException;
	//public ArrayList<BankUser> viewTransaction(BankUser bu4);

}
