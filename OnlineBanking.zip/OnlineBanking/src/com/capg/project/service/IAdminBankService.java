package com.capg.project.service;

/*
 * Author by Kumar Satyam
 * Last modified on 08 Sep 2018 
 */

import java.util.ArrayList;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.BankAdmin;
import com.capg.project.bean.BankUser;

public interface IAdminBankService {
	public int createNewAccount(BankAdmin bankAdmin) throws OnlineBankingException;
	 public ArrayList<BankUser> viewTransaction(int account_id,int tranDuration) throws OnlineBankingException;	
}
