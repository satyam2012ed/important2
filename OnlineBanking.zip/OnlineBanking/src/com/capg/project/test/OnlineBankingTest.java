package com.capg.project.test;

/*
 * Author by Kumar Satyam
 * Last modified on 07 Sep 2018 
 */

import static org.junit.Assert.*;

import org.junit.Test;

public class OnlineBankingTest {

	@Test
	public void testCreateNewAccount() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewTransaction() {
		fail("Not yet implemented");
	}

}
