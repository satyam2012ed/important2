package com.capg.project.test;

/*
 * Author by Kumar Satyam
 * Last modified on 10 Sep 2018 
 */

import static org.junit.Assert.*;

import org.junit.Test;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.dao.IUserBankDAO;
import com.capg.project.dao.UserBankDAOImpl;

public class OnlineBankTest {

	@Test
	public void testLogin() throws OnlineBankingException {
		IUserBankDAO dao = new UserBankDAOImpl();
		assertEquals(0, dao.login("5555","user"));
		assertEquals(1, dao.login("8888","admin"));
		assertEquals(-1, dao.login("4555","user"));
		assertNotEquals(0, dao.login("5567","user"));
		
	}

	@Test
	public void testChangeInCommunicationAddressStringStringString() throws OnlineBankingException {
		IUserBankDAO dao = new UserBankDAOImpl();
		assertEquals(1,dao.changeInCommunicationAddress("5555"));
		assertEquals(1,dao.changeInCommunicationAddress("5555","Chennai","8976789657"));
	}
}
